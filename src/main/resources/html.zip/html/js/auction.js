function buy(form) {
    var ar = $(form).serializeArray();
    $.ajax({
        url: form.action,
        data: $(form).serialize(),
        success: function (data) {
            if (data == "ok") {
                $(form).hide();
                $('#' + ar[1].value).html("Done");
            } else if (data == "no") {
                $('#error').html('Invalid');
            } else {
                $(form).hide();
                $('#' + ar[1].value).html(data);
            }
        },
        error: function (error) {

        },
        dataType: "text"
    });

    return false;
};

var table = function (by) {
    oTable = $('#mainTable').dataTable({
        "sDom": "<'row'<'span4'l><'span4'f>r>t<'row'<'span4'i><'span4'p>>",
        "sPaginationType": "bootstrap",
        "bProcessing": true,
        "bStateSave": false,
        "bDestroy": true,
        "oSearch": { "sSearch": "" },
        "bServerSide": true,
        "sAjaxSource": by,
        "oLanguage": {
            "sProcessing": jsIndex['sProcessing'],
            "sLengthMenu": jsIndex['sLengthMenu'],
            "sZeroRecords": jsIndex['sZeroRecords'],
            "sInfo": jsIndex['sInfo'],
            "sInfoEmpty": jsIndex['sInfoEmpty'],
            "sInfoFiltered": jsIndex['sInfoFiltered'],
            "sSearch": jsIndex['sSearch'],
            "sInfoPostFix": "",
            "sUrl": "",
            "oPaginate": {
                "sFirst": jsIndex['sFirst'],
                "sPrevious": jsIndex['sPrevious'],
                "sNext": jsIndex['sNext'],
                "sLast": jsIndex['sLast']
            }
        },
        "fnServerData": function (sSource, aoData, fnCallback) {
            $.ajax({
                "dataType": 'json',
                "type": "GET",
                "url": sSource,
                "data": aoData,
                "success": fnCallback,
                "timeout": 15000,
                "error": handleAjaxError
            });
        }
    });
};
$(document).ready(function () {
    table("fill/auction/byall");

    $(".byall").click(function () {
        table("fill/auction/byall");
    });

    $(".byblock").click(function () {
        table("fill/auction/byblock");
    });

    $(".byCombat").click(function () {
        table("fill/auction/bycombat");
    });

    $(".byDecoration").click(function () {
        table("fill/auction/bydecoration");
    });

    $(".byFood").click(function () {
        table("fill/auction/byfood");
    });

    $(".byMaterials").click(function () {
        table("fill/auction/bymaterials");
    });

    $(".byMicellaneous").click(function () {
        table("fill/auction/bymicellaneous");
    });

    $(".byOthers").click(function () {
        table("fill/auction/byothers");
    });

    $(".byRedstone").click(function () {
        table("fill/auction/byredstone");
    });

    $(".byTools").click(function () {
        table("fill/auction/bytools");
    });

    $(".byTransportation").click(function () {
        table("fill/auction/bytransportation");
    });

    $(".byBrewing").click(function () {
        table("fill/auction/bybrewing");
    });
    
});
