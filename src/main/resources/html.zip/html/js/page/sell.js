$(function () {
    AjaxTable(0, 10);
});

var to = 10;

var AjaxTable = function (to, from) {
    $.ajax({
        url: "/myauctions/get",
        data: "to=" + to + "&from=" + from + "&sessionid=" + getCookie("sessionid"),
        success: function (data) {
            try {
                LoadTable(data);
            } catch (err) {
                $('#resultado').html(err);
            };
        },
        error: function (error) {
            $('#resultado').html(error);
        },
        dataType: "json"
    });
};

function remitem(form) {
    $.ajax({
        url: "/myauctions/cancel",
        data: $(form).serialize() + "&sessionid=" + getCookie("sessionid"),
        success: function (data) {
            $('#formresult').html(data);
            to = 10;
            AjaxTable(0, 10);
        },
        error: function (error) {
            $('#formresult').html(error);
        },
        dataType: "text"
    });
    return false;
};