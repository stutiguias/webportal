$(function () {
    get("", "/adm/getinfo");
});

var get = function(form,url) {
    $.ajax({
        url: url,
        success: function (data) {
            try {
                var result = "";
                $(".theadInput").html("");
                $.each(data, function (key, val) {
                    $.each(val, function (key, val) {
                        $(".theadInput").html($(".theadInput").html() + "<th>" + key + "</th>");
                    });
                    return false;
                });

                $.each(data, function (key, val) {
                    result += "<tr>";
                    $.each(val, function (key, val) {
                        result += "<td>" + val + "</td>";
                    });
                    result += "</tr>";
                });

                $(".tbodyInput").html(result);
            } catch (err) {
                $('#resultado').html(err.message);
            };
        },
        error: function (error,data) {
            $('#resultado').html(error);
        },
        dataType: "json"
    });
}

function viewplugins(form) {
    get(form, "/adm/viewplugins");
    return false;
}

function sendmsg(form) {
    $.ajax({
        url: "/adm/sendmsg",
        data: $(form).serialize(),
        success: function (data) {
            $('#resultado').html(data);
        },
        error: function (error, data) {
            $('#resultado').html(error);
        },
        dataType: "text"
    });
    return false;
}

function sendcmd(form) {
    $.ajax({
        url: "/adm/sendcmd",
        data: $(form).serialize(),
        success: function (data) {
            var result = "";
            $.each(data, function (key, val) {
                result += "<br />" + val.replace("[m","").replace("<","[").replace(">","]").replace("[0;31;1m","");
            });
            $('.console').html(result);
        },
        error: function (error, data) {
            $('#resultado').html(error);
        },
        dataType: "json"
    });
    return false;
}

function shutdown(form) {
    $.ajax({
        url: "/adm/shutdown",
        success: function (data) {
            $('#resultado').html(data);
        },
        error: function (error, data) {
            $('#resultado').html(error);
        },
        dataType: "text"
    });
    return false;
}


function reload(form) {
    $.ajax({
        url: "/adm/reload",
        success: function (data) {
            $('#resultado').html(data);
        },
        error: function (error, data) {
            $('#resultado').html(error);
        },
        dataType: "text"
    });
    return false;
}


function adm(form) {
    $.ajax({
        url: admsearch,
        data: $(form).serialize(),
        success: function (data) {
            try {
                var result = "";
                $(".theadInput").html("");
                $.each(data, function (key, val) {
                    $.each(val, function (key, val) {
                        $(".theadInput").html($(".theadInput").html() + "<th>" + key + "</th>");
                    });
                    return false;
                });
         
                $.each(data, function (key, val) {
                    result += "<tr>";
                    $.each(val, function (key, val) {
                        result += "<td>" + val + "</td>";
                    });
                    result += "</tr>";
                });
                
                $(".tbodyInput").html(result);
            } catch (err) {
                $('#resultado').html(err);
            };
        },
        error: function (error) {
            $('#resultado').html(error);
        },
        dataType: "json"
    });

    return false;
};

function additem(form) {
    $.ajax({
        url: "/adm/addshop",
        data: $(form).serialize(),
        success: function (data) {
            if (data.indexOf("ok") == -1) {
                $('#resultado').html(data);
            } else {
                $('#resultado').html("Sucess Create Server Auction");
            }
        },
        error: function (error) {
            $('#resultado').html(error);
        },
        dataType: "text"
    });

    return false;
};

function del(form) {
    $(form).hide();
    $.ajax({
        url: "/adm/deleteshop",
        data: $(form).serialize(),
        success: function (data) {
            $('#resultado').html(data);
        },
        error: function (error) {
            $('#resultado').html(error);
        },
        dataType: "text"
    });

    return false;
};

function listshop(form) {
    list(0, 10);
    return false;
};

var to = 10;

function list(to,from) {
    $.ajax({
        url: "/adm/shoplist",
        data: "DisplayStart=" + to + "&DisplayLength=" + from,
        success: function (data) {
            try {
                LoadTable(data);
            } catch (err) {
                $('#resultado').html(err);
            };
        },
        error: function (error) {
            $('#resultado').html(error);
        },
        dataType: "json"
    });
}

var LoadTable = function (data) {
    var result = "";
    var total;
    $(".theadInput").html("");
    $.each(data, function (key, val) {
        total = key;
        $.each(val, function (key, val) {
            $.each(val, function (key, val) {
                $(".theadInput").html($(".theadInput").html() + "<th>" + key + "</th>");
            });
            return false;
        });
    });

    $.each(data, function (key, val) {

        $.each(val, function (key, val) {
            result += "<tr>";
            $.each(val, function (key, val) {
                result += "<td>" + val + "</td>";
            });
            result += "</tr>";
        });

    });
    $("#resultado").html("<a id='prev' href='#'>< Previous</a> Showing " + (to - 10) + " - " + to + " of " + total + " <a id='next' href='#'>Next ></a>");
    $("#next").click(function (e) {
        e.preventDefault();
        if (total > to) {
            list(to, to + 10);
            to = to + 10;
        }
    });
    $("#prev").click(function (e) {
        e.preventDefault();
        if (to > 10) {
            to = to - 10;
            list(to - 10, to);
        }
    });
    $(".tbodyInput").html(result);
};