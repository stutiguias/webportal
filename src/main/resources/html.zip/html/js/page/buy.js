var to = 10;

function additem(form) {
    $.ajax({
        url: "/buy/additem",
        data: $(form).serialize() + "&sessionid=" + getCookie("sessionid"),
        success: function (data) {
            $('#formresult').html(data);
            to = 10;
            AjaxTable(0, 10);
        },
        error: function (error) {
            $('#formresult').html(error);
        },
        dataType: "text"
    });
    return false;
};

function remitem(form) {
    $.ajax({
        url: "/buy/remitem",
        data: $(form).serialize() + "&sessionid=" + getCookie("sessionid"),
        success: function (data) {
            $('#formresult').html(data);
            to = 10;
            AjaxTable(0, 10);
        },
        error: function (error) {
            $('#formresult').html(error);
        },
        dataType: "text"
    });
    return false;
};

$(function () {
    AjaxTable(0, 10);
});

var AjaxTable = function (to, from) {
    $.ajax({
        url: "/buy/getitem",
        data: "to=" + to + "&from=" + from + "&sessionid=" + getCookie("sessionid"),
        success: function (data) {
            try {
                LoadTable(data);
            } catch (err) {
                $('#resultado').html(err);
            };
        },
        error: function (error) {
            $('#resultado').html(error);
        },
        dataType: "json"
    });
};