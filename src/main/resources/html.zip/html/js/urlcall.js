
var userinfo = "/server/username/info";

// Auction
var buyUrl = "/auction/buy";

// Admin Search
var admsearch = "/adm/search";