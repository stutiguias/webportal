var login = "/web/login";

var getAuction = "/get/auction?to=0&from=10";
var urlbox1 = "/box/1";
var urlbox2 = "/box/2";

// MyItems Call
var postAuctions = "/myitems/postauction";
var postMail = "/mail/send";

var userinfo = "/server/username/info";

// Auction
var buyUrl = "/auction/buy";

// MyAuction
var cancelUrl = "/myauctions/cancel";

// Admin Search
var admsearch = "/adm/search";