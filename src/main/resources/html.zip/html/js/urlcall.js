var login = "/web/login";

var getAuction = "/get/auction?to=0&from=10";
var urlbox1 = "/box/1";
var urlbox2 = "/box/2";

var postAuctions = "/web/postauction";
var postMail = "/web/mail";

var userinfo = "/server/username/info";

var buyUrl = "/buy/item";
var cancelUrl = "/cancel/auction";
